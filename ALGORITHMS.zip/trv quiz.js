//If you know a solution is not far from the root of the tree:
//BFS
//If the tree is very deep and solutions are rare: 
//BFS as (DFS will take very long time)
//If the tree is very wide:
//DFS as (BFS will need too much memory and too much time)
//If solutions are frequent but located deep in the tree:
//DFS
//Determining whether a path exists between two nodes:
//DFS
//Finding the shortest path: // BFS